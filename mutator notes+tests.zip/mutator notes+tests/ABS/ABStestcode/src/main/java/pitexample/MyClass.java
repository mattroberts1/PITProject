package pitexample;
public class MyClass {
	public int add(int a, int b)
	{
		return a+b;
	}
}