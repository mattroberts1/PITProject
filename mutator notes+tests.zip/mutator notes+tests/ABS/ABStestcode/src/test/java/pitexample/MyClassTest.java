package pitexample;
import org.junit.Test;
import static org.junit.Assert.*;
public class MyClassTest {
	@Test
	public void testAdd() {
		MyClass test = new MyClass();
		assertTrue((test.add(2,3)==5)//unmutated
|| (test.add(2,3)==1));//or a (2) was changed to negative
	}
}