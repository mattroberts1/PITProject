package pitexample;
public class MyClass {
	public int add1(int a, int b)
	{
		return a+b;
	}
		public int add2(int a, int b)
	{
		return a+b;
	}
		public int add3(int a, int b)
	{
		return a+b;
	}
}