package pitexample;
import org.junit.Test;
import static org.junit.Assert.*;
public class MyClassTest {
	@Test
	public void testAdd1() {
		MyClass test = new MyClass();
		assertTrue(test.add1(1,2)==3);
	}
		@Test
	public void testAdd2() {
		MyClass test = new MyClass();
		assertTrue(test.add2(1,2)==3||test.add2(1,2)==1);//should fail when first var is used
	}
		@Test
	public void testAdd3() {
		MyClass test = new MyClass();
		assertTrue(test.add3(1,2)==3||test.add3(1,2)==2);//should fail when second var is used
	}
}