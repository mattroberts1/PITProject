package pitexample;

import org.junit.Test;
import static org.junit.Assert.*;

public class MyClassTest {

  @Test
  public void testplus() {
    MyClass test = new MyClass();
	assertTrue((test.add(1,2)==3) || (test.add(7,9)==-2));
  }
 
  
}