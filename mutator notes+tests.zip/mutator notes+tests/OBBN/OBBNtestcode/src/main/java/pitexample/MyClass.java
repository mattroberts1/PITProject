package pitexample;
public class MyClass {
	public int and(int a, int b)
	{
		return a&b;
	}
	public int or(int a, int b)
	{
		return a|b;
	}
	public int xor(int a, int b)
	{
		return a^b;
	}
}