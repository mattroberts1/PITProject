package pitexample;
import org.junit.Test;
import static org.junit.Assert.*;

public class MyClassTest {

	@Test
	public void testAND() {
		MyClass test = new MyClass();
		assertTrue(test.and(5,6)==4);
	}
	@Test
	public void testOR() {
		MyClass test = new MyClass();
		assertTrue(test.or(5,6)==7);
	}
		@Test
	public void testXOR() {
		MyClass test = new MyClass();
		assertTrue(test.xor(5,6)==3);
	}
}