package pitexample;
public class MyClass {
	public boolean gtr(int a, int b)
	{
		if(a>b)
		{return true;}
		else
			return false;
	}

}