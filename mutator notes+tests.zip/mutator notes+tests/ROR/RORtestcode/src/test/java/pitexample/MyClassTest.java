package pitexample;
import org.junit.Test;
import static org.junit.Assert.*;
public class MyClassTest {
	@Test
	public void testAdd() {
		MyClass test = new MyClass();
		assertTrue(test.gtr(5,3));
		assertFalse(test.gtr(3,3));
	}
}