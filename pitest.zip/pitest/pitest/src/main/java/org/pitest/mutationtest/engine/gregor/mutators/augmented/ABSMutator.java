//replaces a variable with its negation
package org.pitest.mutationtest.engine.gregor.mutators.augmented;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.pitest.mutationtest.engine.MutationIdentifier;
import org.pitest.mutationtest.engine.gregor.MethodInfo;
import org.pitest.mutationtest.engine.gregor.MethodMutatorFactory;
import org.pitest.mutationtest.engine.gregor.MutationContext;


public enum ABSMutator implements MethodMutatorFactory {

    ABS_MUTATOR;

    public MethodVisitor create(final MutationContext context, final MethodInfo methodInfo,
            final MethodVisitor methodVisitor) {
        return new ABSMethodVisitor(this, methodInfo, context, methodVisitor);
    }

    public String getGloballyUniqueId() {
        return this.getClass().getName();
    }

    public String getName() {
        return name();
    }
}

class ABSMethodVisitor extends MethodVisitor {

    private final MethodMutatorFactory factory;
    private final MutationContext context;
    private final MethodInfo info;

    ABSMethodVisitor(final MethodMutatorFactory factory, final MethodInfo info, final MutationContext context,
            final MethodVisitor delegateMethodVisitor) {
        super(Opcodes.ASM5, delegateMethodVisitor);
        this.factory = factory;
        this.context = context;
        this.info = info;
    }

    private boolean shouldMutate(String message) {
        if (context.getClassInfo().isEnum()) {
            return false;
        } 
		else 
		{
            final MutationIdentifier newId = this.context.registerMutation(this.factory, message);
            return this.context.shouldMutate(newId);
        }
    }

    @Override
    public void visitVarInsn(int opcode, int var) {
        mv.visitVarInsn(opcode, var); 
        if(opcode==Opcodes.ILOAD)
		{
			if (this.shouldMutate("Negated local integer variable number " + var)) 
			{
                mv.visitInsn(Opcodes.INEG);
            }
		}
		if(opcode==Opcodes.FLOAD)
		{
			if (this.shouldMutate("Negated local float variable number " + var)) 
			{
                mv.visitInsn(Opcodes.FNEG);
            }
		}

		if(opcode==Opcodes.LLOAD)
		{
			if (this.shouldMutate("Negated local long variable number " + var)) 
			{
                mv.visitInsn(Opcodes.LNEG);
            }
		}
		if(opcode==Opcodes.DLOAD)
		{
			if (this.shouldMutate("Negated local double variable number " + var)) 
			{
                mv.visitInsn(Opcodes.DNEG);
			}	
		}
    }

    @Override
    public void visitFieldInsn(int opcode, String owner, String name, String desc) {

        mv.visitFieldInsn(opcode, owner, name, desc);
        if (opcode == Opcodes.GETFIELD) 
		{
            if (desc.equals("B")) {
                if (this.shouldMutate("Negated byte field " + name)) 
				{
                    mv.visitInsn(Opcodes.INEG);
                    mv.visitInsn(Opcodes.I2B);
                    return;
                }
            }
            if (desc.equals("D")) {
                if (this.shouldMutate("Negated double field " + name)) 
				{
                    mv.visitInsn(Opcodes.DNEG);
                    return;
                }
            }
            if (desc.equals("F")) {
                if (this.shouldMutate("Negated float field " + name)) 
				{
                    mv.visitInsn(Opcodes.FNEG);
                    return;
                }
            }
            if (desc.equals("I")) {
                if (this.shouldMutate("Negated integer field " + name)) 
				{
                    mv.visitInsn(Opcodes.INEG);
                    return;
                }
            }
            if (desc.equals("J")) {
                if (this.shouldMutate("Negated long field " + name)) 
				{
                    mv.visitInsn(Opcodes.LNEG);
                    return;
                }
            }
            if (desc.equals("S")) {
                if (this.shouldMutate("Negated short field " + name)) 
				{
                    mv.visitInsn(Opcodes.INEG);
                    mv.visitInsn(Opcodes.I2S);
                    return;
                }
            }
        }
        if (opcode == Opcodes.GETSTATIC) {
			if (desc.equals("B")) {
                if (this.shouldMutate("Negated static byte field " + name)) 
				{
                    mv.visitInsn(Opcodes.INEG);
                    mv.visitInsn(Opcodes.I2B);
                    return;
                }
            }
            if (desc.equals("D")) {
                if (this.shouldMutate("Negated static double field " + name)) 
				{
                    mv.visitInsn(Opcodes.DNEG);
                    return;
                }
            }
            if (desc.equals("F")) {
                if (this.shouldMutate("Negated static float field " + name)) 
				{
                    mv.visitInsn(Opcodes.FNEG);
                    return;
                }
            }
            if (desc.equals("I")) {
                if (this.shouldMutate("Negated static integer field " + name)) 
				{
                    mv.visitInsn(Opcodes.INEG);
                    return;
                }
            }
            if (desc.equals("J")) {
                if (this.shouldMutate("Negated static long field " + name)) 
				{
                    mv.visitInsn(Opcodes.LNEG);
                    return;
                }
            }
            if (desc.equals("S")) {
                if (this.shouldMutate("Negated static short field " + name)) 
				{
                    mv.visitInsn(Opcodes.INEG);
                    mv.visitInsn(Opcodes.I2S);
                    return;
                }
            }
        }
    }
}
