//replaces arithmetic operation with first operand
package org.pitest.mutationtest.engine.gregor.mutators.augmented;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.pitest.mutationtest.engine.gregor.mutators.OpcodeToType;
import org.pitest.mutationtest.engine.MutationIdentifier;
import org.pitest.mutationtest.engine.gregor.MethodInfo;
import org.pitest.mutationtest.engine.gregor.MethodMutatorFactory;
import org.pitest.mutationtest.engine.gregor.MutationContext;


public enum AODMutator1 implements MethodMutatorFactory  {

  AOD_MUTATOR1;

  public MethodVisitor create(final MutationContext context, final MethodInfo methodInfo, final MethodVisitor methodVisitor)  
  {
    return new AODMethodVisitor1(this, context, methodInfo, methodVisitor);
  }

  public String getGloballyUniqueId()  {
    return this.getClass().getName();
  }

  public String getName()  {
    return name();
  }
}

class AODMethodVisitor1 extends MethodVisitor  {

  private final MethodMutatorFactory factory;
  private final MutationContext      context;
  private final MethodInfo      info;

  AODMethodVisitor1(final MethodMutatorFactory factory, final MutationContext context, final MethodInfo info, final MethodVisitor delegateMethodVisitor)  
  {
    super(Opcodes.ASM5, delegateMethodVisitor);
    this.factory = factory;
    this.context = context;
    this.info = info;
  }
  
  private boolean shouldMutate(String expression) 
  {
      if (info.isGeneratedEnumMethod()) {
          return false;
      } 
	  else 
	  {
          final MutationIdentifier newId = this.context.registerMutation(this.factory, "Replaced " + expression + " with first variable");
          return this.context.shouldMutate(newId);
      }
          
  }
    @Override
public void visitInsn(int opcode)
  {
//integers
  if(opcode==Opcodes.IADD || opcode==Opcodes.ISUB || opcode==Opcodes.IMUL || opcode==Opcodes.IDIV || opcode==Opcodes.IREM)
  {
	if (this.shouldMutate(OpcodeToType.typeOfOpcode(opcode)))  
	{
        mv.visitInsn(Opcodes.POP);
    } 
	else  
	{
       mv.visitInsn(opcode);
    }
  }
//longs
  else if(opcode==Opcodes.LADD || opcode==Opcodes.LSUB || opcode==Opcodes.LMUL || opcode==Opcodes.LDIV || opcode==Opcodes.LREM)
  {
	if (this.shouldMutate(OpcodeToType.typeOfOpcode(opcode)))  
	{
        mv.visitInsn(Opcodes.POP2);
    } 
	else  
	{
        mv.visitInsn(opcode);
    }
  }
//doubles
   else if(opcode==Opcodes.DADD || opcode==Opcodes.DSUB || opcode==Opcodes.DMUL || opcode==Opcodes.DDIV || opcode==Opcodes.DREM)
  {
	if (this.shouldMutate(OpcodeToType.typeOfOpcode(opcode)))  
	{
        mv.visitInsn(Opcodes.POP2);
    } 
	else  
	{
        mv.visitInsn(opcode);
    }
  }
//floats
  else if(opcode==Opcodes.FADD || opcode==Opcodes.FSUB || opcode==Opcodes.FMUL || opcode==Opcodes.FDIV || opcode==Opcodes.FREM)
  {
	if (this.shouldMutate(OpcodeToType.typeOfOpcode(opcode)))  
	{
        mv.visitInsn(Opcodes.POP);
    } 
	else  
	{
       mv.visitInsn(opcode);
    }
  }
  else 
  {
	  mv.visitInsn(opcode);
  }
  }
}
