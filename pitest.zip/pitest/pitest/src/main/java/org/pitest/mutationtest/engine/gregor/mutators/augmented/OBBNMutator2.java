//OBBN mutator: swaps each bitwise operator (or, and, xor) with each of the others (done in 2 files)

package org.pitest.mutationtest.engine.gregor.mutators.augmented;
import java.util.HashMap;
import java.util.Map;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.pitest.mutationtest.engine.gregor.AbstractInsnMutator;
import org.pitest.mutationtest.engine.gregor.InsnSubstitution;
import org.pitest.mutationtest.engine.gregor.MethodInfo;
import org.pitest.mutationtest.engine.gregor.MethodMutatorFactory;
import org.pitest.mutationtest.engine.gregor.MutationContext;
import org.pitest.mutationtest.engine.gregor.ZeroOperandMutation;

public enum OBBNMutator2 implements MethodMutatorFactory {

  OBBN_MUTATOR2;

  public MethodVisitor create(final MutationContext context,
      final MethodInfo methodInfo, final MethodVisitor methodVisitor) {
    return new OBBNMethodVisitor2(this, methodInfo, context, methodVisitor);
  }

  public String getGloballyUniqueId() {
    return this.getClass().getName();
  }

  public String getName() {
    return name();
  }
}

class OBBNMethodVisitor2 extends AbstractInsnMutator {

  OBBNMethodVisitor2(final MethodMutatorFactory factory,
      final MethodInfo methodInfo, final MutationContext context,
      final MethodVisitor writer) {
    super(factory, methodInfo, context, writer);
  }

  private static final Map<Integer, ZeroOperandMutation> MUTATIONS = new HashMap<Integer, ZeroOperandMutation>();

  static {
    // integers
    MUTATIONS.put(Opcodes.IAND, new InsnSubstitution(Opcodes.IXOR,
        "Replaced integer and with xor"));
    MUTATIONS.put(Opcodes.IOR, new InsnSubstitution(Opcodes.IXOR,
        "Replaced integer or with xor"));
	MUTATIONS.put(Opcodes.IXOR, new InsnSubstitution(Opcodes.IAND,
        "Replaced integer xor with and"));

    // longs
    MUTATIONS.put(Opcodes.LAND, new InsnSubstitution(Opcodes.LXOR,
        "Replaced long and with xor"));
    MUTATIONS.put(Opcodes.LOR, new InsnSubstitution(Opcodes.LXOR,
        "Replaced long or with xor"));
		MUTATIONS.put(Opcodes.LXOR, new InsnSubstitution(Opcodes.LAND,
        "Replaced long xor with and"));
  }

  @Override
  protected Map<Integer, ZeroOperandMutation> getMutations() {
    return MUTATIONS;
  }
}
