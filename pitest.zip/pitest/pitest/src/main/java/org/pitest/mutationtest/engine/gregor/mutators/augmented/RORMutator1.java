//replaces a relational operator with each of the other ones
package org.pitest.mutationtest.engine.gregor.mutators.augmented;

import java.util.HashMap;
import java.util.Map;

import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.pitest.mutationtest.engine.gregor.AbstractJumpMutator;
import org.pitest.mutationtest.engine.gregor.MethodInfo;
import org.pitest.mutationtest.engine.gregor.MethodMutatorFactory;
import org.pitest.mutationtest.engine.gregor.MutationContext;

public enum RORMutator1 implements MethodMutatorFactory {

  ROR_MUTATOR1;

  public MethodVisitor create(final MutationContext context,
      final MethodInfo methodInfo, final MethodVisitor methodVisitor) {
    return new RORMethodVisitor1(this, context, methodVisitor);
  }

  public String getGloballyUniqueId() {
    return this.getClass().getName();
  }

  public String getName() {
    return name();
  }

}

class RORMethodVisitor1 extends AbstractJumpMutator {

  private static final Map<Integer, Substitution> MUTATIONS   = new HashMap<Integer, Substitution>();

  static {
      // > to >=
    MUTATIONS.put(Opcodes.IFGT, new Substitution(Opcodes.IFGE, 
        "Replaced greater than with greater or equal"));
    MUTATIONS.put(Opcodes.IF_ICMPGT, new Substitution(Opcodes.IF_ICMPGE,
        "Replaced greater than with greater or equal"));
    
    // >= to >
    MUTATIONS.put(Opcodes.IFGE, new Substitution(Opcodes.IFGT, 
        "Replaced greater than or equal with greater"));
    MUTATIONS.put(Opcodes.IF_ICMPGE, new Substitution(Opcodes.IF_ICMPGT,
        "Replaced greater than or equal with greater"));
    
    // < to <=
    MUTATIONS.put(Opcodes.IFLT, new Substitution(Opcodes.IFLE, 
        "Replaced less than with less or equal"));
    MUTATIONS.put(Opcodes.IF_ICMPLT, new Substitution(Opcodes.IF_ICMPLE,
        "Replaced less than with less or equal"));
        
    // <= to <
    MUTATIONS.put(Opcodes.IFLE, new Substitution(Opcodes.IFLT, 
        "Replaced less or equal with less than"));
    MUTATIONS.put(Opcodes.IF_ICMPLE, new Substitution(Opcodes.IF_ICMPLT,
        "Replaced less or equal with less than"));
            
    // == to !=
    MUTATIONS.put(Opcodes.IFEQ, new Substitution(Opcodes.IFNE,
        "Replaced equal with not equal"));
    MUTATIONS.put(Opcodes.IF_ICMPEQ, new Substitution(Opcodes.IF_ICMPNE,
        "Replaced equal with not equal"));
        
    // != to =
    MUTATIONS.put(Opcodes.IFNE, new Substitution(Opcodes.IFEQ, 
        "Replaced not equal with equal"));
    MUTATIONS.put(Opcodes.IF_ICMPNE, new Substitution(Opcodes.IF_ICMPEQ,
        "Replaced not equal with equal"));
        
    // == null to !=null
    MUTATIONS.put(Opcodes.IFNULL, new Substitution(Opcodes.IFNONNULL,
        "Replaced if null with if not null"));
    
    // != null to ==null
    MUTATIONS.put(Opcodes.IFNONNULL, new Substitution(Opcodes.IFNULL,
        "Replaced if not null with if null"));
    
  }

  RORMethodVisitor1(final MethodMutatorFactory factory,
      final MutationContext context, final MethodVisitor delegateMethodVisitor) {
    super(factory, context, delegateMethodVisitor);
  }

  @Override
  protected Map<Integer, Substitution> getMutations() {
    return MUTATIONS;
  }

}
