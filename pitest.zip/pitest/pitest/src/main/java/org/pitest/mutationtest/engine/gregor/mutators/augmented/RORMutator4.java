//replaces a relational operator with each of the other ones
package org.pitest.mutationtest.engine.gregor.mutators.augmented;
import java.util.HashMap;
import java.util.Map;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.pitest.mutationtest.engine.gregor.AbstractJumpMutator;
import org.pitest.mutationtest.engine.gregor.MethodInfo;
import org.pitest.mutationtest.engine.gregor.MethodMutatorFactory;
import org.pitest.mutationtest.engine.gregor.MutationContext;

public enum RORMutator4 implements MethodMutatorFactory {

  ROR_MUTATOR4;

  public MethodVisitor create(final MutationContext context,
      final MethodInfo methodInfo, final MethodVisitor methodVisitor) {
    return new RORMethodVisitor4(this, context, methodVisitor);
  }

  public String getGloballyUniqueId() {
    return this.getClass().getName();
  }

  public String getName() {
    return name();
  }

}

class RORMethodVisitor4 extends AbstractJumpMutator {

  private static final Map<Integer, Substitution> MUTATIONS   = new HashMap<Integer, Substitution>();

  static {
      // > to ==
    MUTATIONS.put(Opcodes.IFGT, new Substitution(Opcodes.IFEQ, 
        "Replaced greater than with equal"));
    MUTATIONS.put(Opcodes.IF_ICMPGT, new Substitution(Opcodes.IF_ICMPEQ,
        "Replaced greater than with equal"));
    
    // >= to ==
    MUTATIONS.put(Opcodes.IFGE, new Substitution(Opcodes.IFEQ, 
        "Replaced greater or equal with equal"));
    MUTATIONS.put(Opcodes.IF_ICMPGE, new Substitution(Opcodes.IF_ICMPEQ,
        "Replaced greater or equal with equal"));
    
    // < to ==
    MUTATIONS.put(Opcodes.IFLT, new Substitution(Opcodes.IFEQ, 
        "Replaced less than with equal"));
    MUTATIONS.put(Opcodes.IF_ICMPLT, new Substitution(Opcodes.IF_ICMPEQ,
        "Replaced less than with equal"));
        
    // <= to ==
    MUTATIONS.put(Opcodes.IFLE, new Substitution(Opcodes.IFEQ, 
        "Replaced less or equal with equal"));
    MUTATIONS.put(Opcodes.IF_ICMPLE, new Substitution(Opcodes.IF_ICMPEQ,
        "Replaced less or equal with equal"));
            
    // == to <=
    MUTATIONS.put(Opcodes.IFEQ, new Substitution(Opcodes.IFLE,
        "Replaced equal with less or equal"));
    MUTATIONS.put(Opcodes.IF_ICMPEQ, new Substitution(Opcodes.IF_ICMPLE,
        "Replaced equal with less or equal"));
        
    // != to <=
    MUTATIONS.put(Opcodes.IFNE, new Substitution(Opcodes.IFLE, 
        "Replaced not equal with less or equal"));
    MUTATIONS.put(Opcodes.IF_ICMPNE, new Substitution(Opcodes.IF_ICMPLE,
        "Replaced not equal with less or equal"));

  }

  RORMethodVisitor4(final MethodMutatorFactory factory,
      final MutationContext context, final MethodVisitor delegateMethodVisitor) {
    super(factory, context, delegateMethodVisitor);
  }

  @Override
  protected Map<Integer, Substitution> getMutations() {
    return MUTATIONS;
  }

}
