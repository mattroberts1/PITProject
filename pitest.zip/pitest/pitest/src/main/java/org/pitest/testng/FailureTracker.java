package org.pitest.testng;

public interface FailureTracker {
  boolean hasHadFailure();
}
