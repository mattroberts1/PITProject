package com.example;

public class CoveredByABeforeAfterClass {
  public static int returnOne() {
    return 1;
  }
}
