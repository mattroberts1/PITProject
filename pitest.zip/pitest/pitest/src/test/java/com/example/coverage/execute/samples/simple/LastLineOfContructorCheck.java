package com.example.coverage.execute.samples.simple;

public class LastLineOfContructorCheck {
  public LastLineOfContructorCheck() {
    super();
  }

}
