package com.example.coverage.execute.samples.simple;

public class OneBlock {
  int foo() {
    return 1;
  }
}
