package com.example.testng;

public abstract class AbstractTestNGClass {
  @org.testng.annotations.Test
  public void aTest() {

  }

  @org.testng.annotations.Test
  public void anotherTest() {

  }
}